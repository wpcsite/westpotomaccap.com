function toggleSidebar() {
  if (sidebar.style.display === 'block') {
    sidebar.style.display = 'none';
  } else {
    sidebar.style.display = 'block';
  }
}

function closeSidebar() {
  sidebar.style.display = 'none';
}
